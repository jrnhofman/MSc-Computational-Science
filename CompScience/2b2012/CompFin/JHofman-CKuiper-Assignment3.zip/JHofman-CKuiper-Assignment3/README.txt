Jeroen Hofman, Carlo Kuiper,

Computational Finance, Assignment 3:

Contents:
- pdf: report on assignment 3
- CN/FTCS.m - finite difference method functions
- stability.m - stability parameter for FTCS
- assignment3.m - script using the above functions
