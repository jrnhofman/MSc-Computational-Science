Code for assignment 1, Computational Finance
Jeroen Hofman
Carlo Kuiper

AmCall.m AmPut.m EuCall.m EuPut.m: MATLAB functions computing the corresponding option price using a binomial tree.

hedge_sim.m: MATLAB function performing a hedging simulation.

script_1_1.m: MATLAB script for part I of the assigment. See comments in script for details.

script_1_2.m: MATLAB script for part II of the assignment. See comments in script for details.
