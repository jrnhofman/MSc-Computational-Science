Jeroen Hofman, Carlo Kuiper,

Computational Finance, Assignment 2:

Contents:
- pdf: report on assignment 2
- asian.c - geometric asian option MC
- asian_variate.cpp - geometric asian option MC with control variate (arithmetic asian option)
- digital.c - delta hedge for digital option
- EurCallPut.c - European call and put option pricing MC
- EurCallPut_anti.c - European call and put option pricing MC with antithetic variables
- sens.c - delta hedge for European call and put MC
- .m files - some analytical evaluations to check the results
