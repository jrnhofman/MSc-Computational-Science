/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fishSchool;
import as.model.Fish;
import sim.engine.*;
import sim.util.*;
import sim.util.Double3D;
import java.util.ArrayList;

/**
 *
 * @author Daniel
 */
public class Fish3D implements Steppable{
    public Fish model_fish;
    public static final float radius = 5.0f;
    
    public Fish3D(Fish existing_fish) {
        model_fish = existing_fish;
    }
    
    public Fish3D(double x, double y, double z) {
        model_fish = new Fish(x,y,z);
    }
    
    public void step(final SimState state ) {
        FishSchool fs = (FishSchool) state;
        SchoolUpdater updater = fs.getUpdater();
        ArrayList<Fish> visjes = updater.getVisjes();
        //if the fish is still alive, update position
        if( visjes.contains(model_fish)) {
            Double3D next_pos = new Double3D(model_fish.getX(),model_fish.getY(),model_fish.getZ());
            fs.setFishLocation(this, next_pos);
        } else {
            //if it is not alive anymore, remove it from the sea
            fs.fish_environment.remove(this);
            fs.sea_environment.remove(this);
            
        }
        
    }
    
}
