/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fishSchool;
import as.model.Model;
import as.model.Fish;
import as.model.Shark;
import java.util.ArrayList;
import sim.field.continuous.*;
import sim.engine.*;
import sim.display3d.*;
import sim.util.*;
import javax.swing.*;
import sim.display.*;
/**
 *
 * @author Daniel
 */
public class FishSchool extends SimState{
    
    public static final double XMIN = 0;
    public static final double XMAX = 200;
    public static final double YMIN = 0;
    public static final double YMAX = 200;
    public static final double ZMIN = 0;
    public static final double ZMAX = 200;
    
    public static final double DIAMETER = 1;
    
    public static int num_fish = Model.N;
    public static final double TIMESTEP = 30;
    
    public Display3D display;
    public JFrame displayFrame;

    //Why two spaces??
    public Continuous3D sea_environment = new Continuous3D( 2*DIAMETER, XMAX-XMIN, YMAX-YMIN, ZMAX-ZMIN );
    public Continuous3D fish_environment = null;
    
    //private Model school;
    private SchoolUpdater school_updater;
    
    public FishSchool(long seed) {
        super(seed);
    }
    
    public final static double EXTRA_SPACE = 10;
    public static final double MAX_DISTANCE = 10*DIAMETER; //guessed from Rmax in as.model.model and WoimsDemo3D
    
    public void start()
    {
        super.start(); // clear out the schedule
        sea_environment = new Continuous3D( 2*DIAMETER, XMAX-XMIN, YMAX-YMIN, ZMAX-ZMIN );
        fish_environment = new Continuous3D( MAX_DISTANCE,XMAX-XMIN, YMAX-YMIN, ZMAX-ZMIN );
        
        //initialize the model
        school_updater = new SchoolUpdater(new Model());
        schedule.scheduleRepeating(school_updater);
        
        //initialize the fish
        ArrayList<Fish> visjes = school_updater.getVisjes();
        num_fish = visjes.size();
        
        for(int idx = 0; idx < num_fish; idx++)
        {
            Fish3D fish = new Fish3D(visjes.get(idx));
            Double3D loc = new Double3D(fish.model_fish.getX(),fish.model_fish.getY(),fish.model_fish.getZ());
            sea_environment.setObjectLocation( fish, loc );
            fish_environment.setObjectLocation( fish, loc );
            //schedule.scheduleRepeating(fish); //the SchoolUpdater will update the fish
        }
        
        Shark model_shark = school_updater.getShark();
        Shark3D visual_shark = new Shark3D(model_shark);
        Double3D shark_loc = new Double3D(model_shark.getX(), model_shark.getY(), model_shark.getZ());
        sea_environment.setObjectLocation(visual_shark, shark_loc);
        schedule.scheduleRepeating(visual_shark);
         
     }
    
    public void setFishLocation( final Fish3D fish, Double3D location )
    {
        sea_environment.setObjectLocation( fish, location );
        fish_environment.setObjectLocation( fish, location);
    }
    
    public void setSharkLocation(final Shark3D shark, Double3D location){
        sea_environment.setObjectLocation(shark, location);
    }
    
     public static void main(String[] args)
    {
        doLoop(FishSchool.class, args);
        System.exit(0);
    }
     
     
    public static double getBM() {
        return Model.getBM();
    }
    

    public static int getN() {
        return Model.getN();
    }

    public static double getRmax() {
        return Model.getRmax();
    }

    public static double getRmin() {
        return Model.getRmin();
    }

    public static double getDt() {
        return Model.getDt();
    }

    public static double getFmax() {
        return Model.getFmax();
    }

    public static int getInitialRadius() {
        return Model.getInitialRadius();
    }

    public static double getNi() {
        return Model.getNi();
    }

    public static double getNw() {
        return Model.getNw();
    }

    public static double getRandom() {
        return Model.getRandom();
    }

    public static double getTau() {
        return Model.getTau();
    }

    public static double getV0() {
        return Model.getV0();
    }

    public static double getWa() {
        return Model.getWa();
    }

    public static double getWc() {
        return Model.getWc();
    }

    public static double getWpc() {
        return Model.getWpc();
    }

    public static double getWrc() {
        return Model.getWrc();
    }

    public static double getWs() {
        return Model.getWs();
    }

    public static void setBM(double BM) {
        Model.BM = BM;
    }

    public static void setN(int N) {
        Model.N = N;
    }

    public static void setRmax(double Rmax) {
        Model.Rmax = Rmax;
    }

    public static void setRmin(double Rmin) {
        Model.Rmin = Rmin;
    }

    public static void setDt(double dt) {
        Model.dt = dt;
    }

    public static void setFmax(double fmax) {
        Model.fmax = fmax;
    }

    public static void setInitialRadius(int initialRadius) {
        Model.initialRadius = initialRadius;
    }

    public static void setNi(double ni) {
        Model.ni = ni;
    }

    public static void setNw(double nw) {
        Model.nw = nw;
    }

    public static void setRandom(double random) {
        Model.random = random;
    }

    public static void setTau(double tau) {
        Model.tau = tau;
    }

    public static void setV0(double v0) {
        Model.v0 = v0;
    }

    public static void setWa(double wa) {
        Model.wa = wa;
    }

    public static void setWc(double wc) {
        Model.wc = wc;
    }

    public static void setWpc(double wpc) {
        Model.wpc = wpc;
    }

    public static void setWrc(double wrc) {
        Model.wrc = wrc;
    }

    public static void setWs(double ws) {
        Model.ws = ws;
    }
     
    public SchoolUpdater getUpdater() {
        return school_updater;
    }
}
