/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fishSchool;
import as.model.Shark;
import as.model.Vector;
import sim.engine.*;
import sim.util.*;
import sim.util.Double3D;
/**
 *
 * @author Daniel
 */
public class Shark3D implements Steppable {
    private Shark model_shark = null;
    public static final float radius = 3*Fish3D.radius;
    
    public Shark3D(Shark existing_shark) {
        model_shark = existing_shark;
    }
    
    public Shark3D() {
        model_shark = new Shark();
    }
    
    public void step(final SimState state ) {
        FishSchool fs = (FishSchool) state;
        Double3D next_pos = new Double3D(model_shark.getX(),model_shark.getY(),model_shark.getZ());
        fs.setSharkLocation(this, next_pos);
    }
    
    public Double3D getOrientation() {
        Vector direction = model_shark.getDirection();
        Double3D dir = new Double3D(direction.getX(),direction.getY(),direction.getZ());
        return dir;
    }

        
}
