/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fishSchool;
import as.model.*;
import sim.util.*;
import sim.engine.*;
import sim.portrayal3d.*;
import sim.portrayal3d.simple.*;
import java.util.ArrayList;
/**
 *
 * @author Daniel
 */
public class SchoolUpdater implements Steppable{
    private static Model school_model;
    
    public SchoolUpdater(Model model) {
        school_model = model;
    }
    
    public SchoolUpdater(int n_fish) {
        school_model = new Model(n_fish);
    }
    
    public void init(){
        System.out.println("Apparently SchoolUpdater.init() is also called"); 
    }
    
    @Override
    public void step(final SimState state ){
        school_model.performOneTimeStep();
        FishSchool school = (FishSchool) state;
        Bag fishies = school.fish_environment.getAllObjects();
        for(Object i: fishies){
            if(i.getClass() == Fish3D.class){
                Fish3D fish = (Fish3D) i;
                fish.step(state);
            }
        }
       
        //FishSchool school = (FishSchool) state;
        //Bag fishies = school.fish_environment.getAllObjects();
        if(fishies.isEmpty())
            school.kill();
        
    }
    
    public ArrayList<Fish> getVisjes(){
        return school_model.getVisjes();
    }
    
    public Shark getShark() {
        return school_model.getShark();  
    }
    
}
