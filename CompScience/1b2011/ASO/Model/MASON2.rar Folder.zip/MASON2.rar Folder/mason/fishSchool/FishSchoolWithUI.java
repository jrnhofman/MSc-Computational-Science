/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fishSchool;
import sim.portrayal3d.continuous.*;
import sim.portrayal3d.simple.*;
import sim.portrayal.Inspector;
//import sim.portrayal.simple.*;
import sim.engine.*;
import sim.display.*;
import sim.display3d.*;
import javax.swing.*;
import java.awt.*;


/**
 *
 * @author Daniel
 */
public class FishSchoolWithUI extends GUIState{
    public Display3D display;
    public JFrame displayFrame;
    java.awt.Color[] colors = new java.awt.Color[FishSchool.num_fish];
    
    //ContinuousPortrayal3D fishPortrayal = new ContinuousPortrayal3D();
    //final static double extra_space = 10; //for wire frame
    
    public static void main(String[] args)
    {
        new FishSchoolWithUI(new FishSchool(System.currentTimeMillis())).createController();
    }
                
    public FishSchoolWithUI()
    {
        this(new FishSchool(System.currentTimeMillis()));
    }

    ContinuousPortrayal3D sea;
    WireFrameBoxPortrayal3D wireFrame;
    FishSchool school;

    public FishSchoolWithUI(SimState state)
    {
        super(state);
        school = (FishSchool) state;
        sea = new ContinuousPortrayal3D();
        sea.setField(school.sea_environment); 
        double extra_space = 10;
        // build the box
        wireFrame = new WireFrameBoxPortrayal3D(-extra_space,-extra_space,-extra_space,school.sea_environment.width + 2*extra_space,school.sea_environment.height + 2*extra_space,school.sea_environment.length + 2*extra_space);
    }
    
    public static String getName() { return "Fish School Sim"; }
    public static Object getInfo() { return "A 3D model of Fish movement,"
            + "using Hemelrijks equations for movement"; }

    @Override
    public void start()
    {
        super.start();
        setupPortrayals();
    }

    @Override
    public void load(SimState state)
    {
        super.load(state);
        setupPortrayals();
    }

    @Override
    public void quit()
    {
        super.quit();
        if (displayFrame!=null) displayFrame.dispose();
        displayFrame = null;
        display = null;
    }
    
    public void setupPortrayals()
    {
        sea.setField(((FishSchool) state).sea_environment);
        for(int x=0;x<school.fish_environment.allObjects.numObjs;x++)
        {
            /*SimplePortrayal2D basic =       new TrailedPortrayal2D(
                this,
                new OrientedPortrayal2D(
                    new SimplePortrayal2D(), 0, 4.0,
                    new Color(      128 + guirandom.nextInt(128),
                        128 + guirandom.nextInt(128),
                        128 + guirandom.nextInt(128)),
                    OrientedPortrayal2D.SHAPE_COMPASS),
                trailsPortrayal, 100);*/
            //SpherePortrayal3D s = new SpherePortrayal3D(colors[x], 4.0f , 6);
            ConePortrayal3D s = new ConePortrayal3D(Color.GREEN, Fish3D.radius) ; 
            //SpherePortrayal3D s = new SpherePortrayal3D(Color.ORANGE, 6.0f, 6);
            sea.setPortrayalForObject(school.fish_environment.allObjects.objs[x], s); //fishPortrayal
        }
        TransformedPortrayal3D s = setSharkPortrayal();
        sea.setPortrayalForClass(Shark3D.class, s);
        
        display.reset();
        display.createSceneGraph();
    }
    
    @Override
    public void init(Controller c){
        super.init(c);
        //FishSchool school = (FishSchool) state;

        display = new Display3D(600,600,this);
        display.setBackdrop(new Color(0.0f,0.0f,0.3f));
        
        display.attach(sea,"Fish");
        display.attach(wireFrame, "WireFrame");

        display.translate(-.5*FishSchool.XMAX,-.5*FishSchool.YMAX,-.5*FishSchool.ZMAX);
        display.scale(1.0/100);
        displayFrame = display.createFrame();
        
        c.registerFrame(displayFrame);
        displayFrame.setVisible(true);
    }

    @Override
    public Inspector getInspector() {
		Inspector i = super.getInspector();
		i.setVolatile(true);
		return i;
	}
    
    @Override
    public Object getSimulationInspectedObject() {
		return state;
	}
    
    public TransformedPortrayal3D setSharkPortrayal() {
        ConePortrayal3D s = new ConePortrayal3D(Color.RED, Shark3D.radius) ;
        
        TransformedPortrayal3D t = new TransformedPortrayal3D(s);
        t.rotateZ(-90);
        
        return t;
    }
}
