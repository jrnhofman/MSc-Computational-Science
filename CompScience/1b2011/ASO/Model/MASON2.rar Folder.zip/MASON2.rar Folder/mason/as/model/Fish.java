/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package as.model;

import java.util.Random;

/**
 *
 * @author louisdijkstra
 */
public class Fish {

    /* The position of the fish */
    private double x;
    private double y;
    private double z;
    /* The number of neighbors in the seperation, alignment and cohesion zone */
    private int ns; /* seperation */

    private int na; /* alignment */

    private int nc; /* cohesion */

    /* Current speed of the fish */
    private Vector v;
    /* The orientation of the fish */
    private Vector ex;
    /* Range of perception */
    private double Ra; /* alignment zone */

    private double Rc; /* cohesion zone */

    /* Forces computed in the class School */
    private Vector seperationForce;
    private Vector alignmentForce;
    private Vector cohesionForce;
    private Vector fleeForce ; 

    /* Constructor of this class */
    public Fish(double x_, double y_, double z_) {
        x = x_;
        y = y_;
        z = z_;

        ns = 0;
        na = 0;
        nc = 0;

        seperationForce = new Vector();
        alignmentForce = new Vector();
        cohesionForce = new Vector();
        fleeForce = new Vector() ; 

        /* The speed is initially set to cruise speed */
        v = new Vector(Model.v0, 0, 0);

        /* The range of perception is initially maximal */
        Rc = Model.Rmax;
        Ra = 5;

        /* Random orientation ex */
        ex = new Vector(0, 0,0);
        Random randGenerator = new Random();
        ex.setX(randGenerator.nextDouble());
        ex.setY(randGenerator.nextDouble());
        ex.setZ(randGenerator.nextDouble());
        ex.multiplyVector(1 / ex.getNorm());
    }

    public Vector getPosition() {
        return new Vector(x, y, z);
    }

    public Vector getOrientation() {
        return ex;
    }

    /*
     * Applies the different forces to change the position and orientation
     */
    public void update() {
        Vector forceNet = new Vector();
        /* Add all the forces */
        forceNet.add(seperationForce);
        forceNet.add(alignmentForce);
        forceNet.add(cohesionForce);
        forceNet.add(fleeForce) ; 
        Vector speedForce = speedForce();
        Vector pitchForce = pitchForce();
        Vector randomForce = randomForce();

        forceNet.add(speedForce);
        forceNet.add(pitchForce);
        forceNet.add(randomForce);



        /* If the magnitude of the forceNet exceeds the max, rescale it */
        if (forceNet.getNorm() > Model.fmax) {
            double scalar = Model.fmax / forceNet.getNorm();
            forceNet.setX(scalar * forceNet.getX());
            forceNet.setY(scalar * forceNet.getY());
            forceNet.setZ(scalar * forceNet.getZ());
        }

        /*
         * Print all the forces
         */
        //seperationForce.print("Seperation Force ");
        //alignmentForce.print("Alignment Force ");
        //cohesionForce.print("Cohesion Force ");
        //speedForce.print("Speed Force ");
        //pitchForce.print("Pitch Force ");
        //randomForce.print("Random Force ");
        //forceNet.print("Net Force ");
        //getOrientation().print("Orientation ");

        Vector acceleration = Vector.multiply(1 / Model.BM, forceNet);
        Vector vIncrement = Vector.multiply(Model.dt, acceleration);
        Vector vNew = Vector.sum(v, vIncrement);
        //vNew.print("VNew ");
        x += (v.getX() + vNew.getX()) * Model.dt / 2;
        y += (v.getY() + vNew.getY()) * Model.dt / 2;
        z += (v.getZ() + vNew.getZ()) * Model.dt / 2;

        v = vNew;

        ex = Vector.multiply(1.0 / vNew.getNorm(), vNew);
    }

    public void setSeperationForce(Vector sf) {
        seperationForce.setVector(sf.getX(), sf.getY(), sf.getZ());
    }

    public void setAlignmentForce(Vector af) {
        alignmentForce.setVector(af.getX(), af.getY(), af.getZ());
    }

    public void setCohesionForce(Vector cf) {
        cohesionForce.setVector(cf.getX(), cf.getY(), cf.getZ());
    }
    
    public void setFleeForce (Vector ff) {
        fleeForce.setVector(ff.getX(), ff.getY(), ff.getZ());
    }

    /* 
     * Adjusts the speed of the fish (see eq. 5)
     */
    private Vector speedForce() {
        /* The scalar value */
        double a = (Model.v0 - v.getNorm()) / Model.tau;

        Vector sf = new Vector(a * ex.getX(), a * ex.getY(), a * ex.getZ());
        //sf.print("Speed Force in fucntion ");
        return sf;
    }

    /*
     * Computes the pitch force (see eq. 6)
     */
    private Vector pitchForce() {
        return new Vector(0, 0, -1 * Model.wpc * ex.getZ());
    }

    /*
     * Computes the roll force (see eq. 6)
     * 
     * Is not used at the moment!
     */
    private Vector rollForce() {
        return null;
    }
    


    /*
     * Computes the random force. 
     */
    private Vector randomForce() {
        Random randGenerator = new Random();
        //randGenerator.setSeed(3);
        Vector forceRandom = new Vector();

        if (Model.random != 0) {
            /* Generate a random force with a magnitude smaller than Model.random */
            do {
                forceRandom.setX(2 * randGenerator.nextDouble() * Model.random - Model.random);
                forceRandom.setY(2 * randGenerator.nextDouble() * Model.random - Model.random);
                forceRandom.setZ(2 * randGenerator.nextDouble() * Model.random - Model.random);
            } while (forceRandom.getNorm() > Model.random);

        }
        return forceRandom;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double getZ() {
        return z;
    }

    /* 
     * Returns the radius of the alignment zone, Ra.
     */
    public double getRa() {
        return Ra;
    }

    /*
     * Returns the radius of the cohesion zone, Rc. 
     */
    public double getRc() {
        return Rc;
    }

    /*
     * Returns the perception radius. 
     */
    public double getR() {
        return Rc;
    }

    /*
     * Sets the new radius of cohesion and (possibily) alignment
     */
    public void setR(double _Rc) {
        Rc = _Rc;
        if (Rc < Model.Rmin) {
            Rc = Model.Rmin ; 
        }
        
        if (Rc < Ra) {
            Ra = Rc;
        } else {
            Ra = 5;
        }
        
        //System.out.println("R - alignment: " + Ra) ; 
        //System.out.println("R - cohesion: " + Rc) ; 
    }

    public void center(Vector centerSchool) {
        x -= centerSchool.getX();
        y -= centerSchool.getY();
        z -= centerSchool.getZ();
    }
}
