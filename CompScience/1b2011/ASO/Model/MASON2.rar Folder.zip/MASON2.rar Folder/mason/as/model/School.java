/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package as.model;

import java.util.ArrayList;
import java.util.Random;

/**
 * The school of fish. 
 * @author louisdijkstra
 */
public class School {

    private int nFish; /* The total number of fish */

    private ArrayList<Fish> visjes; /* The fish in this school */
    private Shark shark ; 
    
   
    
    /*
     * Default constructor School
     */

    public School(Shark shark_, int _nFish) {
        visjes = new ArrayList<Fish>();
        nFish = _nFish;

        shark = shark_ ; 


        initializeSchool();
    }

    /*
     * Initializes a random school of fish
     * Fish start randomly in a sphere with radius 50 BL
     */
    private void initializeSchool() {
        Random randGenerator = new Random();
        //randGenerator.setSeed(3);
        double x, y, z;

        /* Create new fish */
        for (int i = 0; i < nFish; i++) {

            /* Generate random point until it lies within the sphere */
            do {
                x = randGenerator.nextDouble() * 2 * Model.initialRadius - Model.initialRadius;
                y = randGenerator.nextDouble() * 2 * Model.initialRadius - Model.initialRadius;
                z = randGenerator.nextDouble() * 2 * Model.initialRadius - Model.initialRadius;
            } while (Math.pow(x, 2) + Math.pow(y, 2) + Math.pow(z, 2) >= Math.pow(Model.initialRadius, 2));

            Fish fish = new Fish(x, y, z);
         
            visjes.add(fish);
        }
    }

    public int getNumberOfFish() {
        return visjes.size(); 
    }
    
    /* Executes one time step for every fish in this particular school */
    public void update() {
        /* First, adjust the radii */
        adjustRadii();
        /* Compute all the forces for every fish */
        seperationForce();
        alignmentForce();
        cohesionForce();
        fleeForce () ; 
        
        /* The fish will compute the other forces and update their position and orientation */
        for (Fish fish : visjes) {
            fish.update();
        }
        
        
        
        /* Let the shark move to the closest fish in the school */
        Vector point = visjes.get(0).getPosition() ;
        double minDistance = Vector.computeNorm(Vector.subtract(point, shark.getPosition())) ; 
        for (int i = 1 ; i < visjes.size(); i ++) {
            if (minDistance > Vector.computeNorm(Vector.subtract(visjes.get(i).getPosition(), shark.getPosition()))) {
                point = visjes.get(i).getPosition() ; 
                minDistance = Vector.computeNorm(Vector.subtract(point, shark.getPosition())) ; 
            }
        }
        shark.moveTowards(point);
        
        /* EATING TIME! */
        if (shark.canEat()) {
            
            for (Fish fish : visjes) {
                if (shark.canEat() && Math.pow(fish.getX() - shark.getX(), 2) + Math.pow(fish.getY() - shark.getY(), 2) + Math.pow(fish.getZ() - shark.getZ(), 2) <= Math.pow(Model.Rfeed, 2)) {
                    shark.digest(); 
                    this.removeFish(fish);
                    System.out.println("THE SHARK ATE A FISH!!!, number of fish: " + nFish) ; 
                    break ; 
                }
            }
        } else {
            shark.digest();
        }
        
        /* Center the school */
        centerSchool() ; 
    }

    /* 
     * Adjust the radii of perception of all the fish in the array visjes. 
     * 
     * This function should do the following (in that order):
     *      - walk through the array of visjes
     *      - Determine the number of neighbors (n(t))
     *      - Apply equation no. 1. 
     *      - Call the function setR(newR) in the class Fish. 
     */
    private void adjustRadii() {

        ArrayList<Fish> visjesInZone = new ArrayList<Fish>();

        for (Fish fish : visjes) {
            /* Adjust the radius of this fish */
            visjesInZone = returnFishInCohesionZone(fish.getPosition(), fish.getRc());

            double dR = Model.Rmax - Model.nw * visjesInZone.size();
            double s = Model.ni * Model.dt;
            fish.setR(Math.max(Model.Rmin, (1 - s) * fish.getR() + s * dR));
        }
    }

    private ArrayList<Fish> returnFishInAlignmentZone(Vector position, double radius) {
        ArrayList<Fish> visjesInZone = new ArrayList<Fish>();
        for (Fish fish : visjes) {
            if (!fish.getPosition().equal(position)) {
                if (Math.pow(fish.getX() - position.getX(), 2) + Math.pow(fish.getY() - position.getY(), 2) + Math.pow(fish.getZ() - position.getZ(), 2) < Math.pow(radius, 2)) {

                    Vector ex = fish.getOrientation();
                    double x = (-1 * ex.getY()) / Math.sqrt(Math.pow(ex.getX(), 2) + Math.pow(ex.getY(), 2));
                    double y = ex.getX() / Math.sqrt(Math.pow(ex.getX(), 2) + Math.pow(ex.getY(), 2));
                    Vector ey = new Vector(x, y, 0);
                    Vector c = Vector.crossproduct(ex, ey);
                    double s3 = Math.sqrt(3);

                    Vector g1 = new Vector();
                    Vector g2 = new Vector();

                    Vector r1 = new Vector(-s3 + (2 + s3) * Math.pow(c.getX(), 2), (2 + s3) * c.getX() * c.getY() - c.getZ(), (c.getY() + (2 + s3) * c.getX() * c.getZ()));
                    Vector r2 = new Vector((2 + s3) * c.getX() * c.getY() + c.getZ(), -s3 + (2 + s3) * Math.pow(c.getY(), 2), -c.getX() + (2 + s3) * c.getY() * c.getZ());
                    Vector r3 = new Vector(-c.getY() + (2 + s3) * c.getX() * c.getZ(), c.getX() + (2 + s3) * c.getY() * c.getZ(), -s3 + (2 + s3) * Math.pow(c.getZ(), 2));

                    g1.setX(Vector.inproduct(r1, ex));
                    g1.setY(Vector.inproduct(r2, ex));
                    g1.setZ(Vector.inproduct(r3, ex));

                    r1.setVector(-s3 + (2 + s3) * Math.pow(c.getX(), 2), (2 + s3) * c.getX() * c.getY() + c.getZ(), (-c.getY() + (2 + s3) * c.getX() * c.getZ()));
                    r2.setVector((2 + s3) * c.getX() * c.getY() - c.getZ(), -s3 + (2 + s3) * Math.pow(c.getY(), 2), c.getX() + (2 + s3) * c.getY() * c.getZ());
                    r3.setVector(c.getY() + (2 + s3) * c.getX() * c.getZ(), -c.getX() + (2 + s3) * c.getY() * c.getZ(), -s3 + (2 + s3) * Math.pow(c.getZ(), 2));

                    g2.setX(Vector.inproduct(r1, ex));
                    g2.setY(Vector.inproduct(r2, ex));
                    g2.setZ(Vector.inproduct(r3, ex));

                    g1.multiplyVector(.5);
                    g2.multiplyVector(.5);

                    Vector gN1 = Vector.crossproduct(g1, c);
                    Vector gN2 = Vector.crossproduct(c, g2);
                    
                    if (!(Vector.inproduct(gN1, Vector.subtract(fish.getPosition(), position)) < 0 && Vector.inproduct(gN2, Vector.subtract(fish.getPosition(), position)) < 0)) {
                        gN1.multiplyVector(-1);
                        gN2.multiplyVector(-1);
                        if (!(Vector.inproduct(gN1, Vector.subtract(fish.getPosition(), position)) < 0 && Vector.inproduct(gN2, Vector.subtract(fish.getPosition(), position)) < 0)) {
                            visjesInZone.add(fish);
                        }
                    }
                }
            }
        }
 
        return visjesInZone;
    }

    private ArrayList<Fish> returnFishInCohesionZone(Vector position, double radius) {
        ArrayList<Fish> visjesInZone = new ArrayList<Fish>();
        for (Fish fish : visjes) {
            if (!fish.getPosition().equal(position)) {
                if (Math.pow(fish.getX() - position.getX(), 2) + Math.pow(fish.getY() - position.getY(), 2) + Math.pow(fish.getZ() - position.getZ(), 2) < Math.pow(radius, 2)) {
                    visjesInZone.add(fish); // TODO remove 
                    /*
                    Vector ex = fish.getOrientation();
                    double x = (-1 * ex.getY()) / Math.sqrt(Math.pow(ex.getX(), 2) + Math.pow(ex.getY(), 2));
                    double y = ex.getX() / Math.sqrt(Math.pow(ex.getX(), 2) + Math.pow(ex.getY(), 2));
                    Vector ey = new Vector(x, y, 0);
                    Vector c = Vector.crossproduct(ex, ey);
                    
                    Vector g1 = new Vector();
                    Vector g2 = new Vector();

                    double m = (1 + 1 / Math.sqrt(2));
                    double s = 1 / Math.sqrt(2);

                    Vector r1 = new Vector(-s + m * Math.pow(c.getX(), 2), m * c.getX() * c.getY() - c.getZ() * s, s * c.getY() + m * c.getX() * c.getZ());
                    Vector r2 = new Vector(m * c.getX() * c.getY() + c.getZ() * s, -s + m * Math.pow(c.getY(), 2), -s * c.getX() + m * c.getY() * c.getZ());
                    Vector r3 = new Vector(-c.getY() * s + m * c.getX() * c.getZ(), s * c.getX() + m * c.getY() * c.getZ(), -s + m * Math.pow(c.getZ(), 2));

                    g1.setX(Vector.inproduct(r1, ex));
                    g1.setY(Vector.inproduct(r2, ex));
                    g1.setZ(Vector.inproduct(r3, ex));
         

                    r1.setVector(-s + m * Math.pow(c.getX(), 2), m * c.getX() * c.getY() + c.getZ() * s, -s * c.getY() + m * c.getX() * c.getZ());
                    r2.setVector(m * c.getX() * c.getY() - c.getZ() * s, -s + m * Math.pow(c.getY(), 2), s * c.getX() + m * c.getY() * c.getZ());
                    r3.setVector(c.getY() * s + m * c.getX() * c.getZ(), -s * c.getX() + m * c.getY() * c.getZ(), -s + m * Math.pow(c.getZ(), 2));

                    g2.setX(Vector.inproduct(r1, ex));
                    g2.setY(Vector.inproduct(r2, ex));
                    g2.setZ(Vector.inproduct(r3, ex));
                    
                    Vector gN1 = Vector.crossproduct(g1, c);
                    Vector gN2 = Vector.crossproduct(c, g2);

                    if (!(Vector.inproduct(gN1, Vector.subtract(fish.getPosition(), position)) < 0 && Vector.inproduct(gN2, Vector.subtract(fish.getPosition(), position)) < 0)) {
                        visjesInZone.add(fish);
                    }*/
                } 
            }
        }
        return visjesInZone;
    }

    private ArrayList<Fish> returnFishInSeperationZone(Vector position, double radius) {
        ArrayList<Fish> visjesInZone = new ArrayList<Fish>();
        for (Fish fish : visjes) {
            if (!fish.getPosition().equal(position)) {
                if (Math.pow(fish.getX() - position.getX(), 2) + Math.pow(fish.getY() - position.getY(), 2) + Math.pow(fish.getZ() - position.getZ(), 2) < Math.pow(radius, 2)) {

                    Vector ex = fish.getOrientation();
                    double x = (-1 * ex.getY()) / Math.sqrt(Math.pow(ex.getX(), 2) + Math.pow(ex.getY(), 2));
                    double y = ex.getX() / Math.sqrt(Math.pow(ex.getX(), 2) + Math.pow(ex.getY(), 2));
                    Vector ey = new Vector(x, y, 0);
                    Vector c = Vector.crossproduct(ex, ey);
                    double s3 = Math.sqrt(3);

                    Vector g1 = new Vector();
                    Vector g2 = new Vector();

                    Vector r1 = new Vector(-s3 + (2 + s3) * Math.pow(c.getX(), 2), (2 + s3) * c.getX() * c.getY() - c.getZ(), (c.getY() + (2 + s3) * c.getX() * c.getZ()));
                    Vector r2 = new Vector((2 + s3) * c.getX() * c.getY() + c.getZ(), -s3 + (2 + s3) * Math.pow(c.getY(), 2), -c.getX() + (2 + s3) * c.getY() * c.getZ());
                    Vector r3 = new Vector(-c.getY() + (2 + s3) * c.getX() * c.getZ(), c.getX() + (2 + s3) * c.getY() * c.getZ(), -s3 + (2 + s3) * Math.pow(c.getZ(), 2));

                    g1.setX(Vector.inproduct(r1, ex));
                    g1.setY(Vector.inproduct(r2, ex));
                    g1.setZ(Vector.inproduct(r3, ex));

                    r1.setVector(-s3 + (2 + s3) * Math.pow(c.getX(), 2), (2 + s3) * c.getX() * c.getY() + c.getZ(), (-c.getY() + (2 + s3) * c.getX() * c.getZ()));
                    r2.setVector((2 + s3) * c.getX() * c.getY() - c.getZ(), -s3 + (2 + s3) * Math.pow(c.getY(), 2), c.getX() + (2 + s3) * c.getY() * c.getZ());
                    r3.setVector(c.getY() + (2 + s3) * c.getX() * c.getZ(), -c.getX() + (2 + s3) * c.getY() * c.getZ(), -s3 + (2 + s3) * Math.pow(c.getZ(), 2));

                    g2.setX(Vector.inproduct(r1, ex));
                    g2.setY(Vector.inproduct(r2, ex));
                    g2.setZ(Vector.inproduct(r3, ex));

                    g1.multiplyVector(.5);
                    g2.multiplyVector(.5);

                    Vector gN1 = Vector.crossproduct(g1, c);
                    Vector gN2 = Vector.crossproduct(c, g2);

                    if (!(Vector.inproduct(gN1, Vector.subtract(fish.getPosition(), position)) < 0 && Vector.inproduct(gN2, Vector.subtract(fish.getPosition(), position)) < 0)) {
                        visjesInZone.add(fish);
                    }
                }
  
            }
        }
       
        return visjesInZone;
    }

    /*
     * Computes the seperation force.
     * This function has to do the following:
     *      - for every fish
     *              - compute the seperation force (sf, vector) See equation 2
     *              - call the function setSeperationForce (sf) in the class Fish
     */
    private void seperationForce() {
        Vector sf = new Vector(); /* The seperation force */

        ArrayList<Fish> visjesInZone = new ArrayList<Fish>();

        /* For every fish from visjes, do */
        for (Fish fish_i : visjes) {

            visjesInZone = returnFishInSeperationZone(fish_i.getPosition(), Model.Rmin);

            sf.setVector(0, 0, 0);
            if (visjesInZone.size() > 0) {

                Vector d = new Vector();
                Vector rij = new Vector();

                for (Fish fish_j : visjesInZone) {
                    rij = Vector.subtract(fish_j.getPosition(), fish_i.getPosition());
                    d.add(Vector.multiply(1 / Math.pow(rij.getNorm(), 2), rij));
                }
                d.multiplyVector(-1 / (double)visjesInZone.size());
                sf = Vector.multiply(Model.ws / d.getNorm(), d); 
            }
            fish_i.setSeperationForce(sf);
        }

    }

    /*
     * Computes the alignment force
     * This function has to do the following:
     *      - for every fish
     *              - compute the alignment force (af, vector) See equation 3
     *              - call the function setAlignmentForce (af) in the class Fish
     */
    private void alignmentForce() {
        Vector af = new Vector();

        ArrayList<Fish> visjesInZone = new ArrayList<Fish>();

        /* For every fish from visjes, do */
        for (Fish fish_i : visjes) {
            visjesInZone = returnFishInAlignmentZone(fish_i.getPosition(), fish_i.getRa());

            af.setVector(0, 0, 0);
            if (visjesInZone.size() > 0) {
                //System.out.println("visjes In zone :" + visjesInZone) ; 
                //fish_i.getOrientation().print("Orientation fish i ");
                Vector d = new Vector(0,0,0);
               
                for (Fish fish_j : visjesInZone) {
                    d.add(fish_j.getOrientation());
                    //fish_j.getOrientation().print("Orientation fish j ");
                }
                d.multiplyVector(1.0 / (double)visjesInZone.size());
                d.subtract(fish_i.getOrientation());
                //d.print("Resulting d ");
                af = Vector.multiply(Model.wa / d.getNorm(), d);
               
                
            }
         
            
            
            fish_i.setAlignmentForce(af);
        }

    }

    /*
     * Computes the cohesion force.
     * This function has to do the following:
     *      - for every fish
     *              - compute the cohesion force (cf, vector) 
     *              - call the function setCohesionForce (fs) in the class Fish
     */
    private void cohesionForce() {
        Vector cf = new Vector(); /* The seperation force */

        ArrayList<Fish> visjesInZone = new ArrayList<Fish>();

        /* For every fish from visjes, do */
        for (Fish fish_i : visjes) {
            cf.setVector(0, 0, 0);
            Vector d = new Vector();
            Vector rij = new Vector();
            for (Fish fish_j : visjes) {
                if (!fish_i.getPosition().equal(fish_j.getPosition())) {
                    rij = Vector.subtract(fish_j.getPosition(), fish_i.getPosition());
                    d = Vector.sum(d, Vector.multiply(1.0 / rij.getNorm(), rij));
                }
            }
            d.multiplyVector(-1.0 / nFish);
            cf = Vector.multiply(-1 * Model.wc / d.getNorm(), d);
            fish_i.setCohesionForce(cf);
        }
         /*   
            visjesInZone = returnFishInCohesionZone(fish_i.getPosition(), fish_i.getRc());
            cf.setVector(0, 0, 0);

            if (visjesInZone.size() > 0) {

                Vector d = new Vector();
                Vector rij = new Vector();

                for (Fish fish_j : visjesInZone) {
                    rij = Vector.subtract(fish_j.getPosition(), fish_i.getPosition());
                    d = Vector.sum(d, Vector.multiply(1 / rij.getNorm(), rij));
                }
                d.multiplyVector(-1 / (double)visjesInZone.size());

                cf = Vector.multiply(-1 * Model.wc / d.getNorm(), d);
            }
       
            //System.out.println("Fish in cohesion zone: " + visjesInZone.size()) ; 
            //cf.print("Cohesion force in School ");
            fish_i.setCohesionForce(cf);
        }*/

    }
    
    public void fleeForce () {
        Vector ff = new Vector(); /* The seperation force */
        for (Fish fish : visjes) {
            ff = Vector.subtract(shark.getPosition(), fish.getPosition()) ; 
            ff.multiplyVector(-1*Model.wflee / (ff.getNorm()));
            fish.setFleeForce(ff);
        }
    }
    
    public ArrayList<Fish> getVisjes() {
     return visjes;   
    }
    
    public Shark getShark() {
        return this.shark;
    }
    
    /**
     * Centers the school at the origin. Used for visualization mainly.
     */
    public void centerSchool () {
        Vector center = new Vector (0, 0, 0) ; 
        
        for (Fish fish : visjes) {
            center.add(fish.getPosition()) ; 
        }
        center.multiplyVector(1.0 / nFish);
        
        //center.print("Center school ");
        /*
        for (Fish fish : visjes) {
            fish.center(center);
        }
        
        shark.center(center);
        */
    }
    
    public void removeFish (Fish fish) {
        System.out.println("A fish is removed!") ; 
        visjes.remove(fish);
        nFish -- ; 
    }

}
