/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package as.model;

import java.util.Random;

/**
 *
 * @author louisdijkstra
 */
public class Shark {
    
    private double x ;
    private double y ;
    private double z ;
    
    private double digestionTime ;
    private Vector curr_direction;
    
    public Shark () {
        digestionTime = 0 ; 
        Random rand = new Random() ; 
        do {
            x = rand.nextDouble() * 2 * Model.initialRadiusShark - Model.initialRadiusShark ; 
            y = rand.nextDouble() * 2 * Model.initialRadiusShark - Model.initialRadiusShark ; 
            z = rand.nextDouble() * 2 * Model.initialRadiusShark - Model.initialRadiusShark ; 
        } while (Math.pow(x, 2) + Math.pow(y, 2) +  Math.pow(z, 2) <=  Math.pow(Model.initialRadiusShark, 2)) ;
    }
    
   
    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double getZ() {
        return z;
    }

    public Vector getPosition() {
        return new Vector(x,y,z) ; 
    }
    
    public Vector getDirection() {
        return curr_direction;
    }
    
    public void center(Vector centerSchool) {
        x -= centerSchool.getX();
        y -= centerSchool.getY();
        z -= centerSchool.getZ();
        
        //centerSchool.print("Center School ");
    }
    
    public void moveTowards (Vector point) {
        Vector direction = Vector.subtract(point, getPosition()) ; 
        direction.multiplyVector(1.0 / direction.getNorm());
        x += Model.speedShark * direction.getX() * Model.dt ; 
        y += Model.speedShark * direction.getY() * Model.dt ; 
        z += Model.speedShark * direction.getZ() * Model.dt ; 
        this.curr_direction = direction;
        //getPosition().print("Position shark ");
    }
 
    public boolean canEat () {
        if (digestionTime == 0) {
            return true ; 
        } else {
            return false ; 
        }
    }
    
    public void digest () {
        
        digestionTime += Model.dt ; 
        if (digestionTime >= Model.relaxationTime) {
            digestionTime = 0 ; 
        }
    }
    
}
