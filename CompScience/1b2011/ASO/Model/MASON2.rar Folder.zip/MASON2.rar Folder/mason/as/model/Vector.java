/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package as.model;

/**
 * Vector with 3 elements. 
 * Allows for computing basic things like the sum of two vector and their innerproduct. 
 * 
 * @author louisdijkstra
 */
public class Vector {
    
    private double x ; 
    private double y ;
    private double z ; 
    
    /* 
     * Default constructor of Vector. All the values are initialized as 0. 
     */
    public Vector () {
        x = 0 ; 
        y = 0 ;
        z = 0 ; 
    }
    
    /*
     * Constructor of Vector. 
     */
    public Vector (double x_, double y_, double z_) {
        x = x_ ; 
        y = y_ ; 
        z = z_ ; 
    } 
    
    /*
     * Sums a vector v to this vector and returns the resulting vector.
     */
    public Vector add (Vector v) {
        x += v.getX() ; 
        y += v.getY() ; 
        z += v.getZ() ; 
        return this; 
    }
    
    public Vector subtract (Vector v) {
        x -= v.getX() ; 
        y -= v.getY() ; 
        z -= v.getZ() ; 
        return this; 
    }
    
    /*
     * Applies the innerproduct to this vector and the vector v.
     */
    public double innerproduct (Vector v) {
        return (x * v.getX() + y * v.getY() + z * v.getZ()) ; 
    }
    
    public double getX () {
        return x ; 
    }
    
    public double getY () {
        return y ; 
    }
    
    public double getZ () {
        return z ; 
    }
    
    /*
     * Returns the second norm of this vector. 
     */
    public double getNorm () {
        return Math.sqrt(Math.pow(x, 2) + Math.pow(y, 2) + Math.pow(z, 2)) ; 
    }
    
    public void setX (double x_) {
        x = x_ ; 
    }
    
  
    
    public void setY (double y_) {
        y = y_ ; 
    }
    
    public void setZ (double z_) {
        z = z_ ; 
    }
    
    public void setVector (double x_, double y_, double z_) {
        x = x_ ; 
        y = y_ ; 
        z = z_ ; 
    }
    
    public void multiplyVector (double a_) {
        x = a_ * x ; 
        y = a_ * y ; 
        z = a_ * z ; 
    }
    
    public static Vector multiply (double scalar, Vector v) {
        return new Vector (scalar * v.getX(), scalar * v.getY(), scalar * v.getZ()) ; 
    }
    
    public static Vector sum (Vector v, Vector w) {
        return new Vector(v.getX() + w.getX(), v.getY() + w.getY(), v.getZ() + w.getZ()) ; 
    }
    
    public static Vector subtract (Vector v, Vector w) {
        return new Vector(v.getX() - w.getX(), v.getY() - w.getY(), v.getZ() - w.getZ()) ; 
    }
    
    public static Vector crossproduct (Vector v, Vector w) {
        return new Vector (v.getY() * w.getZ() - v.getZ() * w.getY(), v.getZ() * w.getX() - v.getX() * w.getZ(), v.getX() * w.getY() - v.getY() * w.getX()) ; 
        
    }
    
    public static double computeNorm (Vector v) {
          return Math.sqrt(Math.pow(v.getX(), 2) + Math.pow(v.getY(), 2) + Math.pow(v.getZ(), 2)) ; 
     }
    
    public static double inproduct (Vector v, Vector w) {
        return (v.getX() * w.getX() + v.getY() * w.getY() + v.getZ() * w.getZ()) ; 
    }
    
    public void print (String title) {
        System.out.println(title + "--> x: " + x + " y: " + y + " z: " + z) ; 
    }
    
     public void printPosition () {
        System.out.println("{" + x + ", " + y + ", " + z + "}") ; 
    }
     
    public boolean equal (Vector v) {
        if (v.getX() == x && v.getY() == y && v.getZ() == z) {
            return true ; 
        } else {
            return false; 
        }
    }
    
    
}
