/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package as.model;

import java.lang.Integer;
import java.util.ArrayList;

/**
 *
 * @author louisdijkstra
 */
public class Test {
    
    int maxN = 100 ; 
    int minN = 2; 
    
    private ArrayList<Double> time ;
    
    public Test() {
        time = new ArrayList<Double>() ; 
        for (int i = minN; i < maxN + 1; i ++) {
            Model m = new Model(i) ; 
            while (!m.done()) {
                m.performOneTimeStep();
            }
            time.add(m.getTime());
        }
        
        System.out.print(time) ; 
        
    }
}
