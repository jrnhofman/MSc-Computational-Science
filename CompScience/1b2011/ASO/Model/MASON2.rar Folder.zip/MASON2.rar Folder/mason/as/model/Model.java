/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package as.model;
import java.util.ArrayList;
/**
 *
 * @author louisdijkstra
 */
public class Model {
    
    private School school ; 
    private double time ;
    
    /* 
     * Parameters of the model
     * 
     * You can could from anywhere in this project using for example:
     * Model.v0 ; 
     */
    public static int N = 100 ;          /* The number of fish */ 
    public static double dt = 0.05 ;   /* Time step */
    public static double Rmin = 2 ;    /* Minimal radius */
    public static double Rmax = 15 ;   /* Maximal radius of perception */
    public static double v0 = 2 ;      /* Cruise speed of the fish */
    public static double ws = 10;      /* Weight of seperation */
    public static double wa = 5 ;      /* Weight of alignment */
    public static double wc = 9 ;      /* Weight of cohesion */
    public static double tau = 0.2 ;   /* Relaxation time */
    public static double wpc = 2;      /* Pitch control */
    public static double wrc = 5 ;     /* Roll control */
    public static double random = .5;  /* Absolute value of the size of the random force */
    public static double fmax = 3 ;    /* The maximal force */
    
    public static double ni = 1 ; 
    public static double nw = 0.01 ; // TODO check this!
    
    
    // Shark parameters
    public static double relaxationTime = 1.0 ; 
    public static double Rfeed = 2.0 ; 
    public static double wflee = 12 ; 
    public static double initialRadiusShark = 200 ; 
    public static double speedShark = 25 ; 
    
    /*Added later*/
    public static int initialRadius = 50 ; /* The radius of the sphere the fish start in initially */
    public static double BM  = 1 ;         /* The body mass of a single fish */
    
   
    
    /* 
     * Constructor of Model.
     */
    public Model () {
        time = 0 ; 
        Shark shark = new Shark () ;
        school = new School (shark, N) ; 
    }
    
    public Model (int n_fish) {
        time = 0 ; 
        Shark shark = new Shark () ;
        school = new School (shark, n_fish) ; 
    }
    
    /*
     * Performs one complete time step 
     */
    public void performOneTimeStep () {
        school.update(); 
        time += dt ; 
        //System.out.println("Time " + time) ; 
    }
    
    public double getTime () {
        return time ; 
    }
    
    public boolean done() {
        if (school.getNumberOfFish() < 2) {
            return true ; 
        } else {
            return false ;
        }
    }
    
    /*
     * Visualizes the model
     */
    public void visualize () {
        // TODO 
    }
    
    public ArrayList<Fish> getVisjes() {
        return school.getVisjes();  
    }
    
    public Shark getShark() {
        return school.getShark();  
    }
    
     public static double getBM() {
        return BM;
    }

    public static void setBM(double BM) {
        Model.BM = BM;
    }

    public static int getN() {
        return N;
    }

    public static void setN(int N) {
        Model.N = N;
    }

    public static double getRmax() {
        return Rmax;
    }

    public static void setRmax(double Rmax) {
        Model.Rmax = Rmax;
    }

    public static double getRmin() {
        return Rmin;
    }

    public static void setRmin(double Rmin) {
        Model.Rmin = Rmin;
    }

    public static double getDt() {
        return dt;
    }

    public static void setDt(double dt) {
        Model.dt = dt;
    }

    public static double getFmax() {
        return fmax;
    }

    public static void setFmax(double fmax) {
        Model.fmax = fmax;
    }

    public static int getInitialRadius() {
        return initialRadius;
    }

    public static void setInitialRadius(int initialRadius) {
        Model.initialRadius = initialRadius;
    }

    public static double getNi() {
        return ni;
    }

    public static void setNi(double ni) {
        Model.ni = ni;
    }

    public static double getNw() {
        return nw;
    }

    public static void setNw(double nw) {
        Model.nw = nw;
    }

    public static double getRandom() {
        return random;
    }

    public static void setRandom(double random) {
        Model.random = random;
    }

    public static double getTau() {
        return tau;
    }

    public static void setTau(double tau) {
        Model.tau = tau;
    }

    public static double getV0() {
        return v0;
    }

    public static void setV0(double v0) {
        Model.v0 = v0;
    }

    public static double getWa() {
        return wa;
    }

    public static void setWa(double wa) {
        Model.wa = wa;
    }

    public static double getWc() {
        return wc;
    }

    public static void setWc(double wc) {
        Model.wc = wc;
    }

    public static double getWpc() {
        return wpc;
    }

    public static void setWpc(double wpc) {
        Model.wpc = wpc;
    }

    public static double getWrc() {
        return wrc;
    }

    public static void setWrc(double wrc) {
        Model.wrc = wrc;
    }

    public static double getWs() {
        return ws;
    }

    public static void setWs(double ws) {
        Model.ws = ws;
    }
}
