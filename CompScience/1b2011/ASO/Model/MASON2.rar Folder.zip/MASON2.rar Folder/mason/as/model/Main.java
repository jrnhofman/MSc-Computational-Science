package as.model;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author louisdijkstra
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*Model model = new Model () ; 
        
        for (int i = 0 ; i < 100 ; i ++) {
            System.out.printf("Time: %f\n", model.getTime()) ; 
            model.performOneTimeStep();
        }
        System.out.printf("Time: %f\n", model.getTime()) ; */
        Test test = new Test() ; 
    }
}
