/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mytutorial.tutorial6;
import sim.portrayal3d.continuous.*;
import sim.portrayal3d.simple.*;
import sim.engine.*;
import sim.display.*;
import sim.display3d.*;
import javax.swing.*;
import java.awt.*;
import sim.util.*;
/**
 *
 * @author Daniel
 */
public class Tutorial6WithUI extends GUIState{
    public Display3D display;
    public JFrame displayFrame;
    
    ContinuousPortrayal3D bodyPortrayal = new ContinuousPortrayal3D();
    
     public static void main(String[] args)
    {
        new Tutorial6WithUI().createController();
    }

    public Tutorial6WithUI() { super(new Tutorial6( System.currentTimeMillis())); }
    public Tutorial6WithUI(SimState state) { super(state); }
    public static String getName() { return "Tutorial 6: Planets"; }
    public static Object getInfo() { return "<H2>Tutorial 6</H2> Planetary Orbits"; }

    public void start()
    {
        super.start();
        setupPortrayals();
    }

    public void load(SimState state)
    {
        super.load(state);
        setupPortrayals();
    }

    public void quit()
    {
        super.quit();
        if (displayFrame!=null) displayFrame.dispose();
        displayFrame = null;
        display = null;
    }
    
    public void setupPortrayals()
    {
         Tutorial6 tut = (Tutorial6) state;
        bodyPortrayal.setField(tut.bodies);
        Bag objs = tut.bodies.getAllObjects();
        /*
        // planetary colors
        Color colors[] = {Color.yellow, Color.white, Color.green, 
                Color.blue, Color.red, Color.orange, 
                Color.magenta, Color.cyan, Color.pink, Color.white};
        
        for(int i=0;i<10;i++)
            bodyPortrayal.setPortrayalForObject(
                objs.objs[i], new SpherePortrayal3D(colors[i], 
                        (float) (Math.log(Tutorial6.DIAMETER[i])*50), 50));
        */
        // planetary images
        String imageNames[] = {"sunmap.jpg","mercurymap.jpg","venusmap.jpg",
                "earthmap.jpg","marsmap.jpg","jupitermap.jpg",
                "saturnmap.jpg","uranusmap.jpg","neptunemap.jpg","plutomap.jpg"};

        for(int i=0;i<10;i++)
            {
           TransformedPortrayal3D trans =
                new TransformedPortrayal3D(new SpherePortrayal3D(loadImage(imageNames[i]),
                        (float) (Math.log(Tutorial6.DIAMETER[i])*50),
                    50));
                       
            trans.rotateX(90.0); // move pole from Y axis up to Z axis
            bodyPortrayal.setPortrayalForObject(objs.objs[i], trans);
            }
        
        display.reset();
        display.createSceneGraph();
    }
    
    public void init(Controller c)
    {
        super.init(c);

        Tutorial6 tut = (Tutorial6) state;
        bodyPortrayal.setField(tut.bodies);

        display = new Display3D(600,600,this);
        display.attach(bodyPortrayal, "The Solar System");

        // scale down to fit the region a little beyond pluto into the 2x2x2 box
        display.scale(1.0/(Tutorial6.DISTANCE[Tutorial6.PLUTO]*1.05));
        displayFrame = display.createFrame();
        c.registerFrame(displayFrame);
        displayFrame.setVisible(true);
    }
    
    /** Gets an image relative to the tutorial6 directory */
    public static Image loadImage(String filename)
    { 
        return new ImageIcon(Tutorial6.class.getResource(filename)).getImage(); 
    }
}
