/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mytutorial.tutorial1and2;

import sim.engine.*;
import sim.display.*;
import sim.portrayal.grid.*;
import java.awt.*;
import javax.swing.*;

public class MyTutorial2 extends GUIState
{
    public MyTutorial2() { super(new MyTutorial1(System.currentTimeMillis())); }
    
    public MyTutorial2(SimState state) { super(state); }
    
    public static String getName() { return "Tutorial 2: Daniel"; }
    
    public static Object getInfo()
    {
        return "<H2>Daniel's Game of Life</H2>" + "<p>... with a B-Heptomino"; 
    }
    
    public Display2D display;
    public JFrame displayFrame;
    
    FastValueGridPortrayal2D gridPortrayal = new FastValueGridPortrayal2D();
    
    public void setupPortrayals()
    {
    // tell the portrayals what to portray and how to portray them
    gridPortrayal.setField(((MyTutorial1)state).grid);
    gridPortrayal.setMap(
        new sim.util.gui.SimpleColorMap(
            new Color[] {new Color(0,0,0,0), Color.YELLOW}));
                //new Color[] {Color.BLUE, new Color(0,0,0,0)}));
    }
    
    public void start()
    {
        super.start();      
        setupPortrayals();  // set up our portrayals
        display.reset();    // reschedule the displayer
        display.repaint();  // redraw the display
    }   
    
    public void init(Controller c)
    {
        super.init(c);

        // Make the Display2D.  We'll have it display stuff later.
        MyTutorial1 tut = (MyTutorial1)state;
        display = new Display2D(tut.gridWidth * 4, tut.gridHeight * 4,this);
        displayFrame = display.createFrame();
        c.registerFrame(displayFrame);   // register the frame so it appears in the "Display" list
        displayFrame.setVisible(true);

        display.attach(gridPortrayal,"Life");  // attach the portrayals

        // specify the backdrop color  -- what gets painted behind the displays
        display.setBackdrop(Color.black);
    }
    
    public void load(SimState state)
    {
        super.load(state);      
        setupPortrayals();  // set up our portrayals for the new SimState model
        display.reset();    // reschedule the displayer
        display.repaint();  // redraw the display
    }
    
    public static void main(String[] args)
    {
        new MyTutorial2().createController();
    }
    
}
