This zip file contains the report and elevator.py, the simulation program.
Run it by typing python elevator.py.
It uses matlibplot for plotting, but this is disabled by default.
