#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include "compute.h"
#include "pthread.h"
#include <sys/time.h>

#define sqrt 1.414213562373095048
#define dirw (sqrt/(4*(sqrt+1)))
#define diagw (1/(4*(sqrt+1)))
#define MAKEARRAY_2D(Type,Name,N,M)		\
    Type (*restrict Name)[N][M] = \
	(Type (*restrict)[N][M]) malloc((N)*(M)*sizeof(Type))

/* Declare global variables */
pthread_barrier_t threshold;
pthread_barrier_t results;
pthread_barrier_t final;

struct timeval startTime;
struct timeval endTime;

const struct parameters *px;
struct results *rx;
void *currItx;
void *nextItx;
double *range;

double *tdiff;
double *tmax;
double *tmin;
double *tavg;

void *Loop(void *a)
{
    int row,column,i,localiter;
    double cond,diff;

    const size_t N = px->N;
    const size_t M = px->M;    

    double (*restrict currIt)[N+2][M+2] = (double (*restrict)[N+2][M+2]) currItx;
    double (*restrict nextIt)[N+2][M+2] = (double (*restrict)[N+2][M+2]) nextItx;
    double (*restrict old)[N+2][M+2];

    const int id = *(int*)a;
    const int lowerB = 1+ range[id];
    const int upperB = 1+ range[id+1];

    for(localiter=1; localiter<px->maxiter+1; localiter++)
    {

	/*
	** before first barrier, update, partial report, swap and copy
	*/
	
	//Set difference to zero
	tdiff[id] = 0.;

	//Iteration part
	for(row=lowerB; row<upperB; row++)
	{
	    for(column=1; column<M+1; column++)
	    {

		cond = px->conductivity[(row-1)*M + column -1];
		(*nextIt)[row][column] = cond * (*currIt)[row][column] +
		    (((*currIt)[row][column+1] + 
		    (*currIt)[row][column-1] +
		    (*currIt)[row+1][column] +
		    (*currIt)[row-1][column]) * dirw +
		    ((*currIt)[row-1][column-1] +
		    (*currIt)[row-1][column+1] +
		    (*currIt)[row+1][column+1] +
		     (*currIt)[row+1][column-1]) * diagw) * (1 - cond);
		diff = fabs((*currIt)[row][column] - (*nextIt)[row][column]);
		if(tdiff[id] < diff) { tdiff[id] = diff; } 
	    }
	}

	//Partial results
	if(localiter%px->period==0)
	{
	    tmax[id] = (*nextIt)[1][1];
	    tmin[id] = (*nextIt)[1][1];
	    tavg[id] = 0.;

	    //Calculate mean, max, min and maxdiff
	    for(row=lowerB; row<upperB; row++)
	    {
		for(column=1; column<M+1; column++)
		{
		    tavg[id] += (*nextIt)[row][column];
		    tmax[id] = fmax(tmax[id], (*nextIt)[row][column]);
		    tmin[id] = fmin(tmin[id], (*nextIt)[row][column]);
		}
	    }

	    tavg[id] /= N*M;
	}

	//Copy columns
	for(row=lowerB; row<upperB; row++)
	{
	    (*nextIt)[row][0] = (*nextIt)[row][M];
	    (*nextIt)[row][M+1] = (*nextIt)[row][1];
	}

	//Swap arrays
	old = currIt;
	currIt = nextIt;
	nextIt = old;

        //Barrier to finish copying
	pthread_barrier_wait(&results);

	//Master thread combines data from global arrays
	if(id==0)
	{
	    rx->maxdiff = 0.;
	    for(i=0; i<px->nthreads; i++)
	    {
		rx->maxdiff = fmax(rx->maxdiff,tdiff[i]);
	    }

	    if(localiter%px->period==0)
	    {
		rx->niter = localiter;
		rx->tmin = INFINITY;
		rx->tmax = -INFINITY;
		rx->tavg = 0.;
		for(i=0; i<px->nthreads; i++)
		{
		    rx->tavg += tavg[i];
		    rx->tmax = fmax(rx->tmax,tmax[i]);
		    rx->tmin = fmin(rx->tmin,tmin[i]);
		}
	    
		//Calculate elapsed time
		gettimeofday(&endTime,NULL);
		double tS = startTime.tv_sec + (double) startTime.tv_usec/1000000;
		double tE = endTime.tv_sec + (double) endTime.tv_usec/1000000;
		rx->time = tE - tS;

		//Report results
		report_results(px,rx);
	    }
	}

	//Barrier for threshold check
	pthread_barrier_wait(&threshold);
	
	if(rx->maxdiff<px->threshold)
	{
	    break;
	}
    }
	
    /*
    ** Final results (NOTE: ARRAYS ARE SWAPPED)
    */
 
    tmax[id] = (*currIt)[1][1];
    tmin[id] = (*currIt)[1][1];
    tavg[id] = 0.;

    //Calculate mean, max, min and maxdiff
    for(row=lowerB; row<upperB; row++)
    {
	for(column=1; column<M+1; column++)
	{
	    tavg[id] += (*currIt)[row][column];
	    tmax[id] = fmax(tmax[id], (*currIt)[row][column]);
	    tmin[id] = fmin(tmin[id], (*currIt)[row][column]);
	}
    }

    tavg[id] /= N*M;

    pthread_barrier_wait(&final);

    if(id==0)
    {
	rx->maxdiff = 0.;
	for(i=0; i<px->nthreads; i++)
	{
	    if(tdiff[i]>rx->maxdiff) { rx->maxdiff = tdiff[i]; }
	    //rx->maxdiff = fmax(rx->maxdiff,tdiff[i]);
	}

	rx->niter = localiter-1;
	rx->tmin = INFINITY;
	rx->tmax = -INFINITY;
	rx->tavg = 0.;
	for(i=0; i<px->nthreads; i++)
	{
	    rx->tavg += tavg[i];
	    rx->tmax = fmax(rx->tmax,tmax[i]);
	    rx->tmin = fmin(rx->tmin,tmin[i]);
	}
	    
	//Calculate elapsed time
	gettimeofday(&endTime,NULL);
	double tS = startTime.tv_sec + (double) startTime.tv_usec/1000000;
	double tE = endTime.tv_sec + (double) endTime.tv_usec/1000000;
	rx->time = tE - tS;
    }

    return( NULL);
}

void do_compute(const struct parameters* p, struct results *r)
{
    int row,column,i;

    const size_t N = p->N; //rows
    const size_t M = p->M; //columns

    /* Create two temperature arrays */
    MAKEARRAY_2D(double,currIt,N+2,M+2);
    if(currIt == NULL)
    {
	printf("Could not allocate memory, terminating!\n");
	exit(1);
    }
    MAKEARRAY_2D(double,nextIt,N+2,M+2);
    if(nextIt == NULL)
    {
	printf("Could not allocate memory, terminating!\n");
	exit(1);
    }

    /* Initialize global variables */
    px = p;
    rx = r;
    currItx = currIt;
    nextItx = nextIt;
    tdiff = (double *) malloc(sizeof(double)*p->nthreads);
    tavg = (double *) malloc(sizeof(double)*p->nthreads);
    tmax = (double *) malloc(sizeof(double)*p->nthreads);
    tmin = (double *) malloc(sizeof(double)*p->nthreads);

    if(tdiff==NULL || tavg==NULL || tmax==NULL || tmin==NULL)
    {
	printf("Report array creation failed!");
	exit(1);
    }

    /* Pthread parameters */
    pthread_t thread_ids[p->nthreads];
    pthread_attr_t attr;
    if(pthread_attr_init(&attr) || pthread_barrier_init(&threshold,NULL,p->nthreads) ||
    pthread_barrier_init(&results,NULL,p->nthreads) ||
       pthread_barrier_init(&final,NULL,p->nthreads))
    {
	printf("Creation of pthread_barrier failed!");
	exit(1);
    }
    pthread_attr_setscope(&attr,PTHREAD_SCOPE_SYSTEM);

    /*
    **  Initialise currIt and nextIt (where necessary)
    */

    /* Middle part */
    for(row=1; row<N+1; row++)
    {
	for(column=1; column<M+1; column++)
	{
	    (*currIt)[row][column] = p->tinit[(row-1)*M + column -1];
	}
    }
    
    /* Top and bottom edges (FIXED) */
    for(column=1; column<M+1; column++)
    {
	(*currIt)[0][column] = (*currIt)[1][column];
	(*nextIt)[0][column] = (*currIt)[1][column];
	(*currIt)[N+1][column] = (*currIt)[N][column];
	(*nextIt)[N+1][column] = (*currIt)[N][column];
    }

    /* Edges (FIXED) */
    (*currIt)[0][0] = (*currIt)[1][M]; 
    (*currIt)[0][M+1] = (*currIt)[1][1]; 
    (*currIt)[N+1][0] = (*currIt)[N][M]; 
    (*currIt)[N+1][M+1] = (*currIt)[N][1]; 
    (*nextIt)[0][0] = (*currIt)[1][M]; 
    (*nextIt)[0][M+1] = (*currIt)[1][1]; 
    (*nextIt)[N+1][0] = (*currIt)[N][M]; 
    (*nextIt)[N+1][M+1] = (*currIt)[N][1];     

    /*Columns */
    for(row=1; row<N+1; row++)
    {
	(*currIt)[row][0] = (*currIt)[row][M];
	(*currIt)[row][M+1] = (*currIt)[row][1];
    }

    /*
    ** Scheduler
    */

    range = (double*) malloc(sizeof(double)*(p->nthreads+1));
    for(i=0; i<(N-floor((double)N/p->nthreads)*p->nthreads); i++)
    {
	range[i] = i * floor((double)N/p->nthreads) + 1;
    }
    for(i=(N-floor((double)N/p->nthreads)*p->nthreads); i<p->nthreads; i++)
    {
	range[i] = i * floor((double)N/p->nthreads);
    }
    range[p->nthreads] = N;

    /*
    ** Start of timer
    */

    gettimeofday(&startTime, NULL);

    /*
    ** PThread creation
    */

    int *num = (int *) malloc(sizeof(int)*p->nthreads);
    if(num==NULL)
    {
	printf("Creation of num failed!");
	exit(1);
    }

    for(i=0; i<p->nthreads; i++)
    {
	num[i] = i;
	if(pthread_create(&thread_ids[i], &attr, &Loop,&num[i])!=0)
	{
	    printf("Creation of pthread failed!");
	    exit(1);
	}
    }

    /*
    ** Make sure main thread does not terminate 
    ** before others are done
    */
    
    for(i=0; i<p->nthreads; i++)
    {
	pthread_join(thread_ids[i],NULL);
    }
    
    /* Cleaning up */
    pthread_barrier_destroy(&results);
    pthread_barrier_destroy(&final);
    pthread_barrier_destroy(&threshold);
    pthread_attr_destroy(&attr);
    free(currIt);
    free(nextIt);
    free(tdiff);
    free(tavg);
    free(tmax);
    free(tmin);
    free(num);
    free(range);
}
