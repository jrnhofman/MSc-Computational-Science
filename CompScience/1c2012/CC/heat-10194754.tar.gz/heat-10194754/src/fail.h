#ifndef FAIL_H
#define FAIL_H

/* print a message and terminate */
void die(const char *msg);

#endif
