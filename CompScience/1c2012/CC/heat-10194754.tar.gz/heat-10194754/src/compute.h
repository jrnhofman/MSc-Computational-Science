#ifndef COMPUTE_H
#define COMPUTE_H

#include "input.h"
#include "output.h"

void do_compute(const struct parameters *p, 
                struct results *r);

#endif
